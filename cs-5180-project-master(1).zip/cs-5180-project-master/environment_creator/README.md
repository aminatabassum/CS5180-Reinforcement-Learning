# Environment Creator

Simple web application to create a new racetrack.

## Installation

1. Install dependencies:

```bash
user@programmer~:$ pip install -r requirements.txt
```

## Run the app

1. Run the app:

```bash
user@programmer~:$ python app.py
```

2. Visit the following url in your browser:

```bash
http://127.0.0.1:5000/
```
